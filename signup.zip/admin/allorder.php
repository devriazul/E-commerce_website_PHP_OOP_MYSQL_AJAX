<?php include 'inc/header.php';?>
<?php include 'inc/navbar.php';?>
<?php include 'inc/leftbar.php';?>

all order
<?php include 'inc/footer.php';?>