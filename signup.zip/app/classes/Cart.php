<?php
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 9/25/2020
 * Time: 11:59 PM
 */

namespace App\classes;
require_once '../../vendor/autoload.php';
use App\classes\Manage;

class Cart extends Manage
{

}
